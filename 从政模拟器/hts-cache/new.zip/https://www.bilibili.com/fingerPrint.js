<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html lang="zh-cn">

<head>
    <meta http-equiv="Page-Enter" content="blendTrans(Duration=0.5)">
    <meta http-equiv="Page-Exit" content="blendTrans(Duration=0.5)">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta name="viewport"
        content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta name="spm_prefix" content="333.937">
    <title>出错啦! - bilibili.com</title>
    <style type="text/css">
        html,
        body {
            vertical-align: middle;
            padding: 0;
            margin: 0;
            background: var(--bg3, #f1f2f3);
        }

        .error-container {
            width: 980px;
            margin: 30px auto 30px;
            background: var(--bg1, #ffffff);
            border-radius: 10px;
        }

        .widescreen .error-container {
            width: 1160px;
        }

        .error-panel {
            overflow: hidden;
        }

        .error-panel .rollback-btn {
            display: inline-block;
            line-height: 40px;
            vertical-align: middle;
            text-align: center;
            background: #00a1d6;
            color: var(--text_white, #ffffff);
            border-radius: 4px;
            float: right;
            font-size: 16px;
            transition: 0.2s;
            cursor: pointer;
        }

        .error-panel .rollback-btn:hover {
            background: var(--brand_blue, #00AEEC);
        }

        .error-split {
            width: 100%;
            height: 40px;
        }

        .error-manga {
            padding: 30px;
            text-align: center;
        }

        .error-manga img {
            background-color: var(--text_white, #ffffff);
            max-width: 800px;
        }

        .error-manga .change-img-btn {
            display: block;
            height: 48px;
            width: 150px;
            margin: 30px auto 0;
            line-height: 48px;
            vertical-align: middle;
            text-align: center;
            font-size: 16px;
            background: var(--brand_blue, #00AEEC);;
            color: var(--text_white, #ffffff);;
            border-radius: 4px;
            transition: 0.2s;
        }

        .error-manga .change-img-btn.off {
            background-color: var(--graph_bg_regular, #F1F2F3);
            color: var(--text3, #9499A0);
        }

        div.center {
            position: absolute;
            top: 50%;
            left: 50%;
            margin: -25% 0 0 -320px;
            width: 640px;
            min-height: 427px;
            padding: 0px;
        }

        div.errmsg {
            text-align: left;
            width: 640px;
            line-height: 150%;
        }

        a {
            text-decoration: none;
            color: red;
        }

        .center {
            display: none;
        }

        .h5-container {
            display: none;
        }

        @media screen and (max-width: 500px) {

            #biliMainHeader,
            .error-container {
                display: none;
            }

            .h5-container {
                display: block;
                position: absolute;
                top: 50%;
                left: 50%;
                transform: translate(-50%, -50%);
            }

            .h5__img {
                display: block;
                width: 300px;
            }

            .h5__desc {
                color: #a0a0a0;
                text-align: center;
            }
        }
    </style>
    <link rel="shortcut icon" href="//static.hdslb.com/images/favicon.ico">
    <script type="text/javascript">
        var options = {
            type: 'defaultError'
        }

        window.spmReportData = {};
        window.reportConfig = {
            sample: 1,
            msgObjects: "spmReportData",
        };
    </script>
    <script src="//s1.hdslb.com/bfs/seed/log/report/log-reporter.js"></script>
    <script type="text/javascript" src="//s1.hdslb.com/bfs/static/jinkela/long/js/jquery/jquery1.7.2.min.js"></script>
</head>

<body style="direction: ltr;">
    <div id="biliMainHeader" style="min-height: 64px; background-color: var(--bg1, #ffffff);"></div>
    <div class="error-container">
        <div class="error-panel server-error">
            <img src="//static.hdslb.com/error/very_sorry.png">
            <div style="text-align: center; padding: 0 0 40px 0;">
                <a class="rollback-btn" style="padding: 0 20px; float: none;">返回上一页</a>
            </div>
        </div>
        <div class="error-split">
        </div>
        <div class="error-manga">
        </div>
    </div>
    <div class="h5-container">
        <img class="h5__img" src="//s1.hdslb.com/bfs/static/jinkela/long/bitmap/error_01.png" alt="parse failed">
        <div class="h5__desc">
            <span>Σ(oﾟдﾟoﾉ) 无法找到该页面~</span>
        </div>
    </div>
    <script type="text/javascript" src="//s1.hdslb.com/bfs/seed/laputa-header/bili-header.umd.js"></script>
    <script>
        if (typeof BiliHeader !== 'undefined') {
            const el = document.querySelector('#biliMainHeader')
            const header = new BiliHeader({
                config: {
                    headerType: 'mini',
                    disableSticky: true,
                    tokenSupport: true,
                },
            })
            header.init(el)
        }
    </script>
    <script type="text/javascript" charset="utf-8" src="//s1.hdslb.com/bfs/static/jinkela/long/error/error.js"></script>
</body>

</html>