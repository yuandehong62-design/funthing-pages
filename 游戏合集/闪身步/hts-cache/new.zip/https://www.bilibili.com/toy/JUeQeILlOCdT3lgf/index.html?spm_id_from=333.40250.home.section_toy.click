<!DOCTYPE html><html data-theme="dark"><head><script>(function(){try{
var W=window;if(W.__TOY_PERF__){return;}
var P=W.performance;if(!P||!P.getEntriesByType){return;}
var M={fw:[],sent:false};W.__TOY_PERF__=M;
M.pnow=function(){try{return P.now?P.now():(Date.now()-M.t0);}catch(e){return 0;}};
M.head=Math.round(P.now?P.now():0);
M.t0=Math.round((P.timeOrigin!==undefined&&P.timeOrigin!==null)?P.timeOrigin:
 ((P.timing&&P.timing.navigationStart)||Date.now()));
M.sid=(W.crypto&&W.crypto.randomUUID)?W.crypto.randomUUID():
 (Date.now().toString(36)+"-"+Math.random().toString(36).slice(2,10));
M.fcp=undefined;
M.readFCP=function(){try{
 if(M.fcp!==undefined){return M.fcp;}
 var es=P.getEntriesByType("paint")||[];
 for(var i=0;i<es.length;i++){
  if(es[i].name==="first-contentful-paint"){M.fcp=Math.round(es[i].startTime);return M.fcp;}}
}catch(e){}
return M.fcp;};
try{var po=new W.PerformanceObserver(function(l){try{
 var es=l.getEntries();for(var i=0;i<es.length;i++){
  if(es[i].name==="first-contentful-paint"&&M.fcp===undefined){M.fcp=Math.round(es[i].startTime);
   try{if(M.onFCP){M.onFCP();}}catch(e){}}}
}catch(e){}});
try{po.observe({type:"paint",buffered:true});}catch(e){po.observe({entryTypes:["paint"]});}
}catch(e){}
M.probe=function(){try{
 var hit=[];var d=document;
 var add=function(k){if(hit.indexOf(k)<0){hit.push(k);}};
 if(W.unityInstance||W.UnityLoader||W.createUnityInstance){add("unity");}
 if(W.vm||W.Scratch||W.ScratchVM){add("scratch");}
 if(W.cc||W.cocos){add("cocos");}
 if(W.Godot){add("godot");}
 if(W.PIXI){add("pixi");}
 if(W.Phaser){add("phaser");}
 if(W.THREE){add("three");}
 if(W.BABYLON){add("babylon");}
 if(W.WebAssembly&&W.Module&&(W.Module.asm||W.Module.wasmBinary||W._malloc)){add("wasm");}
 if(W.Vue||d.querySelector&&d.querySelector("[data-v-app]")){add("vue");}
 if(W.React||W.ReactDOM){add("react");}
 for(var i=0;i<hit.length;i++){if(M.fw.indexOf(hit[i])<0){M.fw.push(hit[i]);}}
}catch(e){}};
M.kind=function(){try{
 var cv=document.getElementsByTagName?document.getElementsByTagName("canvas"):[];
 var engine=["unity","scratch","cocos","godot","pixi","phaser","three","babylon"];
 var hasEngine=false;
 for(var i=0;i<engine.length;i++){if(M.fw.indexOf(engine[i])>=0){hasEngine=true;break;}}
 if(cv&&cv.length>0){return hasEngine?"canvas-engine":"canvas";}
 return hasEngine?"dom-engine":"dom";
}catch(e){return "unknown";}};
M.collect=function(withKind){try{
 var nav=(P.getEntriesByType("navigation")||[])[0]||{};
 var o={toy_id:M.toyID,render_mode:M.renderMode,layer:M.layer,
  session_id:M.sid,time_origin:M.t0};
 var put=function(k,v){try{var x=Math.round(v||0);if(x>0){o[k]=x;}}catch(e){}};
 put("ttfb",nav.responseStart);put("dcl",nav.domContentLoadedEventEnd);
 put("load",nav.loadEventEnd);put("doc_bytes",nav.decodedBodySize);
 put("head_ms",M.head);put("transfer_bytes",nav.transferSize);
 put("encoded_bytes",nav.encodedBodySize);
 if(withKind){M.probe();o.kind=M.kind();o.fw=M.fw.join(",");}
 var fcp=M.readFCP();
 if(fcp!==undefined){o.fcp=fcp;}
 if(M.fcpEst!==undefined){o.fcp_est=M.fcpEst;}
 if(M.selfArmed){put("ff_self",M.ffSelf);o.ff_self_src=M.ffSrc||(M.selfDone?"none":"pending");}
 return o;
}catch(e){return null;}};
}catch(e){}})();(function(){try{
var W=window;var M=W.__TOY_PERF__;if(!M){return;}
var NS="toy-shell-ability";var SPM="333.40216.toy-load.0.show";
var OK=["https://www.bilibilitoy.com","https://www.bebox.net"];
M.toyID=44848866654208;M.renderMode=2;
M.layer="shell";
function frame(){return document.querySelector?document.querySelector('iframe'):null;}
var report=function(o){try{
 var r=W.reporterPb;if(!r||typeof r.exposure!=="function"){return;}
 r.exposure(SPM,o);
}catch(e){}};
var NUM={ttfb:6e5,dcl:6e5,load:6e5,head_ms:6e5,fcp:6e5,fcp_est:6e5,ff_self:6e5,
 doc_bytes:2e9,transfer_bytes:2e9,encoded_bytes:2e9,time_origin:4e12,seq:9};
var STR={session_id:64,kind:24,fw:160,ff_self_src:16,flush_reason:8};
var ENUM={kind:"|dom|canvas|dom-engine|canvas-engine|unknown|",
 ff_self_src:"|raf2|pixel|gl-blind|tainted|none|pending|",
 flush_reason:"|est|fcp|up|self|bound|err|"};
var CHARSET={session_id:/^[a-z0-9-]+$/,fw:/^[a-z,]+$/};
M.rx=0;
W.addEventListener('message',function(ev){try{
 var d=ev.data;if(!d||d.ns!==NS||d.type!=='perf'){return;}
 var f=frame();if(!f||ev.source!==f.contentWindow){return;}
 var hit=false;for(var i=0;i<OK.length;i++){if(OK[i]===ev.origin){hit=true;break;}}
 if(!hit){return;}
 if(++M.rx>60){return;}
 var o={};
 for(var k in NUM){if(Object.prototype.hasOwnProperty.call(d,k)){
  var v=Math.round(+d[k]);if(isFinite(v)&&v>0&&v<=NUM[k]){o[k]=v;}}}
 for(var s in STR){
  var t=d[s];if(typeof t!=="string"||t.length<1||t.length>STR[s]){continue;}
  if(ENUM[s]&&ENUM[s].indexOf("|"+t+"|")<0){continue;}
  if(CHARSET[s]&&!CHARSET[s].test(t)){continue;}
  o[s]=t;}
 o.toy_id=M.toyID;o.render_mode=M.renderMode;o.link_id=M.sid;o.layer="content";
 report(o);
}catch(e){}},false);
var flushShell=function(){try{
 if(M.sent){return;}M.sent=true;
 var o=M.collect(false);if(!o){return;}
 delete o.fcp;delete o.fcp_est;o.link_id=M.sid;o.flush_reason="shell";
 report(o);
}catch(e){}};
var arm=function(){try{setTimeout(flushShell,300);}catch(e){flushShell();}};
if(document.readyState==="complete"){arm();}
else{W.addEventListener("load",arm,false);}
}catch(e){}})();</script><link rel="manifest" href="/toy/JUeQeILlOCdT3lgf/manifest.webmanifest" crossorigin="use-credentials"><meta name="apple-mobile-web-app-capable" content="yes"><meta name="mobile-web-app-capable" content="yes"><meta name="apple-mobile-web-app-status-bar-style" content="default"><link rel="apple-touch-icon" href="https://i0.hdslb.com/bfs/static/toy/app/JUeQeILlOCdT3lgf/icon_27652_upload"><script>if("serviceWorker" in navigator){window.addEventListener("load",function(){navigator.serviceWorker.register("/toy/JUeQeILlOCdT3lgf/sw.js",{scope:"/toy/JUeQeILlOCdT3lgf/"}).catch(function(){});});}var __toyDeferredPrompt=null;window.addEventListener("beforeinstallprompt",function(e){e.preventDefault();__toyDeferredPrompt=e;});window.__toyInstall=function(){if(__toyDeferredPrompt){__toyDeferredPrompt.prompt();var p=__toyDeferredPrompt;__toyDeferredPrompt=null;return p.userChoice;}return Promise.resolve({outcome:"unavailable"});};</script><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><link rel="preconnect" href="https://www.bilibilitoy.com" crossorigin><link rel="dns-prefetch" href="https://www.bilibilitoy.com"><title>闪身步</title><script>window.__TOY_META__={toy_id:44848866654208};</script><meta name="spm_prefix" content="333.40216" /><script>(function(){try{var sid=(window.crypto&&window.crypto.randomUUID)?window.crypto.randomUUID():(Date.now().toString(36)+"-"+Math.random().toString(36).slice(2,10));var inApp=/BiliApp/i.test(navigator.userAgent),acc=0,lastTick=Date.now();function fg(){return document.visibilityState==="visible"&&(inApp||document.hasFocus());}setInterval(function(){var now=Date.now(),gap=now-lastTick;lastTick=now;if(gap>2000){return;}if(!fg()){return;}acc+=1000;if(acc<10000){return;}acc-=10000;var r=window.reporterPb;if(!r||typeof r.exposure!=="function"){return;}r.exposure("333.40216.toy-heartbeat.0.show",{toy_id:44848866654208,time:10,session_id:sid});},1000);}catch(e){}})();</script><style>html,body{margin:0;padding:0;height:100%;}html{color-scheme:dark;}body{display:flex;background:Canvas}.toy-shell-stage{display:block;flex:1 1 auto;min-width:0;width:100%;height:100vh;padding:6px 0 6px 6px;box-sizing:border-box;}iframe{display:block;border:0;width:100%;height:100%;border-radius:8px;}.toy-shell-sidebar{flex:0 0 auto;width:64px;background:Canvas;}</style><script>if(window.self!==window.top){window.top.location.replace("https://www.bilibili.com/toy/JUeQeILlOCdT3lgf/index.html?spm_id_from=333.40250.home.section_toy.click");}</script></head><body><div class="toy-shell-stage"><iframe src="https://www.bilibilitoy.com/toy/JUeQeILlOCdT3lgf/index.html?spm_id_from=333.40250.home.section_toy.click" sandbox="allow-scripts allow-forms allow-popups allow-popups-to-escape-sandbox allow-same-origin allow-downloads allow-pointer-lock allow-top-navigation-by-user-activation" allow="pointer-lock" referrerpolicy="no-referrer" allowfullscreen></iframe></div><script src="//s1.hdslb.com/bfs/seed/jinkela/short/reporter-pb/index.js"></script><script>window.reporterPb = new ReporterPb({extra:{toy_id: window.__TOY_META__&&window.__TOY_META__.toy_id}})</script><script src="//s1.hdslb.com/bfs/seed/toy/app/sdk/toy-host.js"></script><script src="//s1.hdslb.com/bfs/seed/toy/app/addon/index.js"></script><aside id="toy-shell-sidebar" class="toy-shell-sidebar" aria-label="Toy 详情"></aside><script src="//s1.hdslb.com/bfs/seed/toy/app/pc-detail/index.js"></script></body></html>